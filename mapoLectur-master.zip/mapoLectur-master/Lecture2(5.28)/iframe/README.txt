A Pen created at CodePen.io. You can find this one at https://codepen.io/hswd/pen/JKQOrq.

 Little iframe design to show your web design/web development works without basic screen captures.