A Pen created at CodePen.io. You can find this one at https://codepen.io/bernardoantunes/pen/inrbh.

 This code is based on this sample:
http://thecodeplayer.com/walkthrough/css3-family-tree

and added the hability to set some nodes vertically.

Not fully tested, it just worked for my needs.